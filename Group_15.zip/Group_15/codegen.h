/*
Group No. 15
ID: 2020A7PS0981P               Name: Utkarsh Darolia
ID: 2020A7PS0084P               Name: Tanveer Singh
ID: 2020A7PS0124P			    Name: Shivam Abhay Pande
ID: 2020A7PS0980P			    Name: Mithil Shah
ID: 2020A7PS0120P			    Name: Kshitij Garg
*/

#include "symbolTable.h"

#ifndef _CODEGEN_H
#define _CODEGEN_H

typedef struct StorageStructure {
    STEntry* storage;
    int capacity;
    int size;
} storageStructure;

void codegen (Ast_Node* root, FILE* fp_asm);

#endif