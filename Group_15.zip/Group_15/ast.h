/*
Group No. 15
ID: 2020A7PS0981P               Name: Utkarsh Darolia
ID: 2020A7PS0084P               Name: Tanveer Singh
ID: 2020A7PS0124P			    Name: Shivam Abhay Pande
ID: 2020A7PS0980P			    Name: Mithil Shah
ID: 2020A7PS0120P			    Name: Kshitij Garg
*/

#include "astDef.h"

#ifndef _AST_H
#define _AST_H

Token_Info* createHeapTokenInfo(Token_Info old_token);

Ast_Node* createASTNode();

void printASTNode(Ast_Node* root);

void printASTNodeSTDOUT(Ast_Node* root, Ast_Node* prev, FILE* fp);

void traverseAST(Ast_Node* root, Ast_Node* prev, FILE* fp);

Ast_Node* generateAST(treeNode* curr, Ast_Node* prev);

Ast_Node* wrapper_create_AST(treeNode* parse_root);

int get_total_ast_memory();

#endif