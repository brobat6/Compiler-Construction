/*
Group No. 15
ID: 2020A7PS0981P               Name: Utkarsh Darolia
ID: 2020A7PS0084P               Name: Tanveer Singh
ID: 2020A7PS0124P			    Name: Shivam Abhay Pande
ID: 2020A7PS0980P			    Name: Mithil Shah
ID: 2020A7PS0120P			    Name: Kshitij Garg
*/

#include "typeCheckDef.h"

#ifndef _TC_H
#define _TC_H

Type checkType(Token_Info* tk_data, Operator op, Type t1, Type t2);

Operator token_to_op(Token t);

Type typecheckdfs(Ast_Node* root);

#endif
