/*
Group No. 15
ID: 2020A7PS0981P               Name: Utkarsh Darolia
ID: 2020A7PS0084P               Name: Tanveer Singh
ID: 2020A7PS0124P			    Name: Shivam Abhay Pande
ID: 2020A7PS0980P			    Name: Mithil Shah
ID: 2020A7PS0120P			    Name: Kshitij Garg
*/

#include <sys/types.h>
#include <time.h>
#include "tree.h"
#include "lexer.h"

#ifndef _PARSER_DEF_H
#define _PARSER_DEF_H

#endif